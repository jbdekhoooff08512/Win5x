"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var common_1 = require("@win5x/common");
console.log('API_ENDPOINTS:', common_1.API_ENDPOINTS);
