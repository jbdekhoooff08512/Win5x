import React, { useState } from 'react';
import ChipSelector from './ChipSelector';
import Chip from './Chip';

const ChipSelectorDemo: React.FC = () => {
  const [selectedChip, setSelectedChip] = useState(20);
  const [bets, setBets] = useState<Record<number, number>>({});

  const handleChipClick = (number: number) => {
    setBets(prev => ({
      ...prev,
      [number]: (prev[number] || 0) + selectedChip
    }));
  };

  const clearBets = () => {
    setBets({});
  };

  const numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];

  return (
    <div className="p-6 bg-gray-900 min-h-screen">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold text-white mb-6 text-center">
          Custom Chip Selector Demo
        </h1>
        
        {/* Chip Selector */}
        <ChipSelector
          selectedChip={selectedChip}
          onChipSelect={setSelectedChip}
        />

        {/* Current Selection Display */}
        <div className="bg-gray-800 rounded-lg p-4 mb-6">
          <h2 className="text-lg font-semibold text-gold-400 mb-3 text-center">
            Current Selection
          </h2>
          <div className="text-center">
            <div className="text-2xl font-bold text-white mb-2">
              Selected Chip: ₹{selectedChip.toLocaleString()}
            </div>
            <div className="text-sm text-gray-400">
              {selectedChip < 10 || selectedChip > 5000 ? 'Custom Amount' : 'Predefined Chip'}
            </div>
          </div>
        </div>

        {/* Number Chips */}
        <div className="bg-gray-800 rounded-lg p-4 mb-6">
          <h2 className="text-lg font-semibold text-gold-400 mb-3 text-center">
            Number Chips (Click to place bets)
          </h2>
          <div className="grid grid-cols-5 gap-3">
            {numbers.map((number) => (
              <Chip
                key={number}
                number={number}
                betAmount={bets[number] || 0}
                onClick={() => handleChipClick(number)}
              />
            ))}
          </div>
        </div>

        {/* Bet Summary */}
        <div className="bg-gray-800 rounded-lg p-4 mb-6">
          <h2 className="text-lg font-semibold text-gold-400 mb-3 text-center">
            Bet Summary
          </h2>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h3 className="text-sm font-semibold text-gray-300 mb-2">Individual Bets:</h3>
              <div className="space-y-1">
                {Object.entries(bets).map(([number, amount]) => (
                  <div key={number} className="text-sm text-white">
                    Number {number}: ₹{amount.toLocaleString()}
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-gray-300 mb-2">Totals:</h3>
              <div className="text-sm text-white">
                <div>Total Bet: ₹{Object.values(bets).reduce((sum, amount) => sum + amount, 0).toLocaleString()}</div>
                <div>Numbers with bets: {Object.keys(bets).length}</div>
                <div>Selected chip: ₹{selectedChip.toLocaleString()}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="text-center">
          <button
            onClick={clearBets}
            className="px-6 py-2 bg-red-600 hover:bg-red-500 text-white font-semibold rounded-lg transition-colors"
          >
            Clear All Bets
          </button>
        </div>

        {/* Test Cases */}
        <div className="mt-8 bg-blue-900 rounded-lg p-4 border border-blue-600">
          <h3 className="text-sm font-semibold text-blue-300 mb-2">Test Cases:</h3>
          <div className="text-xs text-blue-200 space-y-1">
            <div><strong>Valid amounts:</strong> 10, 100, 4999, 5000</div>
            <div><strong>Invalid amounts:</strong> 0, 5, 5001, -10, 10.5</div>
            <div><strong>Features:</strong> Real-time validation, error messages, success feedback</div>
            <div><strong>Integration:</strong> Works with existing chip system and bet calculations</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChipSelectorDemo;
