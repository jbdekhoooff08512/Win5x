import React, { useState, useEffect } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { 
  ArrowLeft,
  CheckCircle,
  AlertTriangle,
  Wallet,
  CreditCard,
  Smartphone
} from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '../contexts/AuthContext';
import { useSocket } from '../contexts/SocketContext';
import { paymentService } from '../services/paymentService';
import { userService } from '../services/userService';
import LoadingSpinner from '../components/LoadingSpinner';
import PasswordVerificationModal from '../components/PasswordVerificationModal';
import { formatCurrency } from '@win5x/common';

const WithdrawPage: React.FC = () => {
  const { user, setUser } = useAuth();
  const { socket } = useSocket();
  const queryClient = useQueryClient();
  const [amount, setAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('');
  const [accountDetails, setAccountDetails] = useState({
    upiId: '',
    phoneNumber: '',
    accountNumber: '',
    ifscCode: '',
    accountHolderName: '',
    walletAddress: '',
  });
  const [step, setStep] = useState<'form' | 'success'>('form');
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [passwordError, setPasswordError] = useState('');
  const [attemptsLeft, setAttemptsLeft] = useState<number | undefined>();
  const [isLocked, setIsLocked] = useState(false);
  const [lockoutTime, setLockoutTime] = useState('');

  // Refresh user data on component mount to get latest wagering info
  useEffect(() => {
    const refreshUserData = async () => {
      try {
        const userData = await userService.getProfile();
        if (setUser) {
          setUser(userData);
        }
      } catch (error) {
        console.error('Failed to refresh user data:', error);
      }
    };

    refreshUserData();
  }, [setUser]);

  // Real-time balance updates via socket
  useEffect(() => {
    if (!socket) return;

    const handleBalanceUpdate = (balanceUpdate: any) => {
      console.log('WithdrawPage: Balance update received', balanceUpdate);
      if (setUser) {
        setUser(prev => prev ? {
          ...prev,
          walletBetting: balanceUpdate.bettingWallet !== undefined ? balanceUpdate.bettingWallet : prev.walletBetting,
          walletGaming: balanceUpdate.gamingWallet !== undefined ? balanceUpdate.gamingWallet : prev.walletGaming,
          wageringRequired: balanceUpdate.wageringRequired !== undefined ? balanceUpdate.wageringRequired : prev.wageringRequired,
          wageringProgress: balanceUpdate.wageringProgress !== undefined ? balanceUpdate.wageringProgress : prev.wageringProgress,
        } : null);
      }
    };

    socket.on('user_balance_update', handleBalanceUpdate);

    return () => {
      socket.off('user_balance_update', handleBalanceUpdate);
    };
  }, [socket, setUser]);

  const paymentMethods = [
    { id: 'upi', name: 'UPI', icon: '📱', fields: ['upiId'] },
    { id: 'bank', name: 'Bank Account', icon: '🏦', fields: ['accountHolderName', 'accountNumber', 'ifscCode'] },
    { id: 'phonepe', name: 'PhonePe', icon: '📱', fields: ['upiId'] },
    { id: 'googlepay', name: 'Google Pay', icon: '💳', fields: ['upiId'] },
    { id: 'paytm', name: 'Paytm', icon: '💰', fields: ['upiId'] },
    { id: 'usdt', name: 'USDT', icon: '₿', fields: ['walletAddress'] },
  ];

  const createWithdrawalMutation = useMutation({
    mutationFn: (data: {
      amount: number;
      paymentMethod: string;
      password: string;
      accountDetails: any;
    }) => paymentService.createWithdrawalRequest(data),
    onSuccess: () => {
      setStep('success');
      setShowPasswordModal(false);
      setPasswordError('');
      setAttemptsLeft(undefined);
      setIsLocked(false);
      setLockoutTime('');
      queryClient.invalidateQueries({ queryKey: ['user-withdrawals'] });
      queryClient.invalidateQueries({ queryKey: ['user-profile'] });
    },
    onError: (error: any) => {
      const errorMessage = error.response?.data?.error || 'Failed to submit withdrawal request';
      
      // Check if it's a password-related error
      if (errorMessage.includes('Invalid password') || errorMessage.includes('attempts remaining')) {
        setPasswordError(errorMessage);
        
        // Extract attempts left from error message
        const attemptsMatch = errorMessage.match(/(\d+) attempts remaining/);
        if (attemptsMatch) {
          setAttemptsLeft(parseInt(attemptsMatch[1]));
        }
      } else if (errorMessage.includes('Account temporarily locked')) {
        setIsLocked(true);
        setPasswordError(errorMessage);
        
        // Extract lockout time from error message
        const timeMatch = errorMessage.match(/try again in (.+?)\./);
        if (timeMatch) {
          setLockoutTime(timeMatch[1]);
        }
      } else {
        toast.error(errorMessage);
        setShowPasswordModal(false);
      }
    },
  });

  const handleSubmit = () => {
    const amountNum = parseFloat(amount);
    
    if (!user || amountNum > (user.walletBetting || 0)) {
      toast.error('Insufficient balance');
      return;
    }
    
    // Check wagering requirement FIRST - before any other validation
    const wageringRequired = user?.wageringRequired || 0;
    const wageringProgress = user?.wageringProgress || 0;
    
    if (wageringRequired > 0 && wageringProgress < wageringRequired) {
      const remaining = wageringRequired - wageringProgress;
      toast.error(`Wagering requirement not met. You need to wager ₹${remaining.toFixed(2)} more before withdrawal.`);
      return;
    }
    
    if (amountNum < 100) {
      toast.error('Minimum withdrawal amount is ₹100');
      return;
    }
    
    if (!paymentMethod) {
      toast.error('Please select a payment method');
      return;
    }

    const selectedMethod = paymentMethods.find(m => m.id === paymentMethod);
    if (!selectedMethod) return;

    // Validate required fields
    const missingFields = selectedMethod.fields.filter(field => 
      !accountDetails[field as keyof typeof accountDetails]?.trim()
    );

    if (missingFields.length > 0) {
      toast.error('Please fill in all required fields');
      return;
    }

    // Only show password modal if wagering requirement is met
    setPasswordError('');
    setAttemptsLeft(undefined);
    setIsLocked(false);
    setLockoutTime('');
    setShowPasswordModal(true);
  };

  const handlePasswordVerify = async (password: string) => {
    const amountNum = parseFloat(amount);
    const selectedMethod = paymentMethods.find(m => m.id === paymentMethod);
    
    if (!selectedMethod) return;

    // Filter only relevant account details
    const relevantDetails = selectedMethod.fields.reduce((acc, field) => {
      acc[field] = accountDetails[field as keyof typeof accountDetails];
      return acc;
    }, {} as any);

    createWithdrawalMutation.mutate({
      amount: amountNum,
      paymentMethod: selectedMethod.name,
      password,
      accountDetails: relevantDetails,
    });
  };

  const resetForm = () => {
    setAmount('');
    setPaymentMethod('');
    setAccountDetails({
      upiId: '',
      phoneNumber: '',
      accountNumber: '',
      ifscCode: '',
      accountHolderName: '',
      walletAddress: '',
    });
    setStep('form');
    setShowPasswordModal(false);
    setPasswordError('');
    setAttemptsLeft(undefined);
    setIsLocked(false);
    setLockoutTime('');
  };

  const selectedMethodObj = paymentMethods.find(m => m.id === paymentMethod);

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-gray-900 p-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            {step === 'success' && (
              <button
                onClick={() => window.history.back()}
                className="p-2 rounded-lg bg-gray-700 hover:bg-gray-600 transition-colors"
              >
                <ArrowLeft className="h-5 w-5 text-white" />
              </button>
            )}
            <div>
              <h1 className="text-3xl font-bold text-white">Withdraw Funds</h1>
              <p className="text-gray-400">Withdraw money from your Win5x wallet</p>
            </div>
          </div>
          
          <div className="text-right">
            <p className="text-gray-400 text-sm">Available Balance</p>
            <p className="text-2xl font-bold text-green-400">
              {formatCurrency(user?.walletBetting || 0, '₹')}
            </p>
            
            {/* Wagering Status */}
            {(user?.wageringRequired ?? 0) > 0 && (
              <div className="mt-3 p-3 bg-gray-800 rounded-lg border border-gray-600">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-gray-400">Wagering Progress</span>
                  <span className="text-xs text-gray-300">
                    {formatCurrency(user?.wageringProgress ?? 0)} / {formatCurrency(user?.wageringRequired ?? 0)}
                  </span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2 mb-2">
                  <div 
                    className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all duration-300"
                    style={{ 
                      width: `${Math.min(100, ((user?.wageringProgress ?? 0) / (user?.wageringRequired ?? 1)) * 100)}%` 
                    }}
                  ></div>
                </div>
                <div className="text-xs text-center">
                  {((user?.wageringProgress ?? 0) >= (user?.wageringRequired ?? 0)) ? 
                    <span className="text-green-400">✅ Ready to withdraw</span> : 
                    <span className="text-yellow-400">
                      ₹{formatCurrency(Math.max(0, (user?.wageringRequired ?? 0) - (user?.wageringProgress ?? 0)))} more to wager
                    </span>
                  }
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Form */}
        {step === 'form' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="card">
              <div className="card-header">
                <h3 className="card-title">Withdrawal Request</h3>
                <p className="card-description">
                  Enter withdrawal details below
                </p>
              </div>
              
              <div className="card-content space-y-6">
                {/* Amount Input */}
                <div>
                  <label className="form-label">Withdrawal Amount</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">₹</span>
                    <input
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      className="form-input pl-8 pr-3"
                      placeholder="Enter amount to withdraw"
                      min="100"
                      max={user?.walletBetting || 0}
                    />
                  </div>
                  <p className="text-sm text-gray-400 mt-1">
                    Min: ₹100 | Available: {formatCurrency(user?.walletBetting || 0, '₹')}
                  </p>
                  
                  {/* Wagering Warning */}
                  {(user?.wageringRequired ?? 0) > 0 && (user?.wageringProgress ?? 0) < (user?.wageringRequired ?? 0) && (
                    <div className="mt-3 p-3 bg-red-900/30 border border-red-500/30 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <AlertTriangle className="h-5 w-5 text-red-400" />
                        <span className="text-red-300 font-semibold">Wagering Requirement Not Met</span>
                      </div>
                      <div className="text-sm text-red-200">
                        <p>You need to wager ₹{Math.max(0, (user?.wageringRequired ?? 0) - (user?.wageringProgress ?? 0)).toFixed(2)} more before withdrawal.</p>
                        <p className="mt-1">Current Progress: ₹{user?.wageringProgress ?? 0} / ₹{user?.wageringRequired ?? 0}</p>
                      </div>
                    </div>
                  )}
                  
                  {/* Wagering Success */}
                  {(user?.wageringRequired ?? 0) > 0 && (user?.wageringProgress ?? 0) >= (user?.wageringRequired ?? 0) && (
                    <div className="mt-3 p-3 bg-green-900/30 border border-green-500/30 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <CheckCircle className="h-5 w-5 text-green-400" />
                        <span className="text-green-300 font-semibold">Wagering Requirement Complete</span>
                      </div>
                      <div className="text-sm text-green-200">
                        <p>✅ You can now withdraw your funds!</p>
                        <p className="mt-1">Progress: ₹{user?.wageringProgress ?? 0} / ₹{user?.wageringRequired ?? 0}</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Payment Method Selection */}
                <div>
                  <label className="form-label">Payment Method</label>
                  <div className="grid grid-cols-2 gap-3">
                    {paymentMethods.map((method) => (
                      <button
                        key={method.id}
                        onClick={() => setPaymentMethod(method.id)}
                        className={`p-4 rounded-lg border-2 transition-all ${
                          paymentMethod === method.id
                            ? 'border-gold-500 bg-gold-500/10'
                            : 'border-gray-600 hover:border-gray-500'
                        }`}
                      >
                        <div className="text-center">
                          <div className="text-2xl mb-2">{method.icon}</div>
                          <p className="text-white font-semibold text-sm">{method.name}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Account Details */}
                {selectedMethodObj && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="space-y-4"
                  >
                    <h4 className="text-lg font-semibold text-white">
                      {selectedMethodObj.name} Details
                    </h4>
                    
                    {selectedMethodObj.fields.includes('upiId') && (
                      <div>
                        <label className="form-label">
                          {selectedMethodObj.name === 'PhonePe' ? 'PhonePe UPI ID' :
                           selectedMethodObj.name === 'Paytm' ? 'Paytm UPI ID' :
                           selectedMethodObj.name === 'Google Pay' ? 'Google Pay UPI ID' :
                           'UPI ID'}
                        </label>
                        <input
                          type="text"
                          value={accountDetails.upiId}
                          onChange={(e) => setAccountDetails(prev => ({ ...prev, upiId: e.target.value }))}
                          className="form-input"
                          placeholder={selectedMethodObj.name === 'PhonePe' ? 'xxxxxxxxxx@ybl' :
                                     selectedMethodObj.name === 'Paytm' ? 'paytm@paytm' :
                                     selectedMethodObj.name === 'Google Pay' ? 'googlepay@okaxis' :
                                     'example@upi'}
                        />
                      </div>
                    )}

                    {selectedMethodObj.fields.includes('phoneNumber') && (
                      <div>
                        <label className="form-label">Phone Number</label>
                        <input
                          type="tel"
                          value={accountDetails.phoneNumber}
                          onChange={(e) => setAccountDetails(prev => ({ ...prev, phoneNumber: e.target.value }))}
                          className="form-input"
                          placeholder="+91 XXXXXXXXXX"
                        />
                      </div>
                    )}

                    {selectedMethodObj.fields.includes('accountNumber') && (
                      <>
                        <div>
                          <label className="form-label">Account Holder Name</label>
                          <input
                            type="text"
                            value={accountDetails.accountHolderName || ''}
                            onChange={(e) => setAccountDetails(prev => ({ ...prev, accountHolderName: e.target.value }))}
                            className="form-input"
                            placeholder="Enter account holder name"
                          />
                        </div>
                        <div>
                          <label className="form-label">Account Number</label>
                          <input
                            type="text"
                            value={accountDetails.accountNumber}
                            onChange={(e) => setAccountDetails(prev => ({ ...prev, accountNumber: e.target.value }))}
                            className="form-input"
                            placeholder="Enter account number"
                          />
                        </div>
                        <div>
                          <label className="form-label">IFSC Code</label>
                          <input
                            type="text"
                            value={accountDetails.ifscCode}
                            onChange={(e) => setAccountDetails(prev => ({ ...prev, ifscCode: e.target.value.toUpperCase() }))}
                            className="form-input"
                            placeholder="BANK0001234"
                          />
                        </div>
                      </>
                    )}

                    {selectedMethodObj.fields.includes('walletAddress') && (
                      <div>
                        <label className="form-label">Wallet Address</label>
                        <input
                          type="text"
                          value={accountDetails.walletAddress}
                          onChange={(e) => setAccountDetails(prev => ({ ...prev, walletAddress: e.target.value }))}
                          className="form-input"
                          placeholder="Enter USDT wallet address"
                        />
                      </div>
                    )}
                  </motion.div>
                )}

                {/* Warning */}
                <div className="bg-yellow-900/30 border border-yellow-500/30 rounded-lg p-4">
                  <div className="flex items-start space-x-2">
                    <AlertTriangle className="h-5 w-5 text-yellow-400 mt-0.5" />
                    <div>
                      <p className="text-yellow-300 font-semibold">Important</p>
                      <ul className="text-yellow-200 text-sm mt-1 space-y-1">
                        <li>• Withdrawals are processed manually by our team</li>
                        <li>• Processing time: 24-48 hours</li>
                        <li>• Ensure account details are correct</li>
                        <li>• Minimum withdrawal: ₹100</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleSubmit}
                  disabled={
                    !amount || 
                    !paymentMethod || 
                    createWithdrawalMutation.isPending ||
                    ((user?.wageringRequired ?? 0) > 0 && (user?.wageringProgress ?? 0) < (user?.wageringRequired ?? 0))
                  }
                  className={`btn btn-lg w-full ${
                    ((user?.wageringRequired ?? 0) > 0 && (user?.wageringProgress ?? 0) < (user?.wageringRequired ?? 0))
                      ? 'btn-disabled opacity-50 cursor-not-allowed'
                      : 'btn-success'
                  }`}
                >
                  {createWithdrawalMutation.isPending ? (
                    <>
                      <LoadingSpinner size="sm" className="mr-2" />
                      Submitting...
                    </>
                  ) : (
                    <>
                      <Wallet className="h-5 w-5 mr-2" />
                      {((user?.wageringRequired ?? 0) > 0 && (user?.wageringProgress ?? 0) < (user?.wageringRequired ?? 0))
                        ? 'Wagering Required'
                        : 'Request Withdrawal'
                      }
                    </>
                  )}
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {/* Success */}
        {step === 'success' && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center space-y-6"
          >
            <div className="card">
              <div className="card-content py-12">
                <div className="w-20 h-20 bg-yellow-600 rounded-full flex items-center justify-center mx-auto mb-6">
                  <CheckCircle className="h-10 w-10 text-white" />
                </div>
                
                <h2 className="text-2xl font-bold text-white mb-4">Withdrawal Request Submitted!</h2>
                <p className="text-gray-300 mb-6">
                  Your withdrawal request has been submitted successfully. Our team will process it within 24-48 hours.
                </p>
                
                <div className="bg-gray-700 rounded-lg p-4 mb-6">
                  <div className="text-sm text-gray-300 space-y-2">
                    <div className="flex justify-between">
                      <span>Amount:</span>
                      <span className="text-yellow-400 font-semibold">₹{amount}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Method:</span>
                      <span className="text-white">{selectedMethodObj?.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Status:</span>
                      <span className="text-yellow-400">Pending Review</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <button
                    onClick={resetForm}
                    className="btn btn-primary btn-lg w-full"
                  >
                    Make Another Withdrawal
                  </button>
                  
                  <button
                    onClick={() => window.history.back()}
                    className="btn btn-outline btn-md w-full"
                  >
                    Back to Game
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Password Verification Modal */}
        <PasswordVerificationModal
          isOpen={showPasswordModal}
          onClose={() => setShowPasswordModal(false)}
          onVerify={handlePasswordVerify}
          isLoading={createWithdrawalMutation.isPending}
          error={passwordError}
          attemptsLeft={attemptsLeft}
          isLocked={isLocked}
          lockoutTime={lockoutTime}
        />
      </div>
    </div>
  );
};

export default WithdrawPage;